import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class Home {
  prompt: string = '';
  isSubmitting = false;

  // Array to store submitted prompts
  submittedPrompts: string[] = [];

  submitPrompt(): void {
    const text = this.prompt.trim();
    if (!text || this.isSubmitting) return;

    this.isSubmitting = true;

    // Simulate async submission
    setTimeout(() => {
      console.log('Submitted prompt:', text);
      this.submittedPrompts.push(text); // Add submitted prompt to array
      this.prompt = ''; // clear input
      this.isSubmitting = false;
    }, 600);
  }

  clearPrompt(): void {
    if (this.isSubmitting) return;
    this.prompt = '';
  }

  get isSubmitDisabled(): boolean {
    return !((this.prompt ?? '').trim()) || this.isSubmitting;
  }
}
